<!doctype html>
<html lang="en">

<head>
    <title>Sidebar 01</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/style.css')); ?>">
    <script src="https://kit.fontawesome.com/6cc7b35ba8.js" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/css/bootstrap-colorpicker.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

</head>

<style>
    @media screen and (max-width: 575.5px) {
        .input-x {
            padding: 0 !important;
        }
    }
</style>

<body>

    <div class="wrapper d-flex align-items-stretch">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.admin-navbar','data' => ['active' => 'Edit Store']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.admin-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => 'Edit Store']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <!-- Page Content  -->
            <div id="content" class="p-4 p-md-5">

                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <div class="container-fluid">

                        <button type="button" id="sidebarCollapse" class="btn btn-primary ">
                            <i class="fa fa-bars"></i>
                            <span class="sr-only">Toggle Menu</span>
                        </button>
                        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="fa fa-bars"></i>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="nav navbar-nav ml-auto">
                                <li class="nav-item">
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <a class="nav-link" href="route('logout')" onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                            <?php echo e(__('Log Out')); ?>

                                        </a>
                                    </form>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                                        <?php echo e(__('Profile')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Content -->
                <?php if(session()->get('mssg')): ?>
                <div class="alert <?php echo e(session()->get('alert')); ?> my-5" role="alert"><?php echo e(session()->get('mssg')); ?></div>
                <?php endif; ?>
                <h6>Edit your store</h6>
                <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('adminUpdateStore')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group my-4">
                        <label for="store_name">Store Name</label>
                        <input type="text" name="name" value="<?php echo e($store['name']); ?>" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="store_name" aria-describedby="store name" placeholder="Enter Store Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group my-4">
                        <label for="url">URL</label>
                        <input type="text" name="url" value="<?php echo e($store['url']); ?>" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="url" aria-describedby="url" placeholder="Enter Store URL">
                        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div id="url-message-danger" class="alert alert-danger mt-1 mb-1 d-none"></div>
                        <div id="url-message-success" class="alert alert-success mt-1 mb-1 d-none"></div>
                    </div>
                    <div class="form-group my-4">
                        <label for="whatsapp">Whatsapp Number</label>
                        <input type="text" name="whatsapp" value="<?php echo e($store['whatsapp']); ?>" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="whatsapp" aria-describedby="store name" placeholder="Enter Store Name">
                        <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="d-flex flex-sm-row flex-column justify-content-between">
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-left: 0;">
                            <label for="color_1">Color 1</label>
                            <input type="text" id="color_1" name="color_1" value="<?php echo e($store['color_1']); ?>" class="<?php $__errorArgs = ['color_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> colorpicker form-control" id="whatsapp" aria-describedby="color 1">
                            <?php $__errorArgs = ['color_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-right: 0;">
                            <label for="color_2">Color 2</label>
                            <input type="text" id="color_3" name="color_2" value="<?php echo e($store['color_2']); ?>" class="<?php $__errorArgs = ['color_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> colorpicker form-control" id="whatsapp" aria-describedby="color 1">
                            <?php $__errorArgs = ['color_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="d-flex flex-sm-row flex-column justify-content-between">
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-left: 0;">
                            <label for="start_time">Start Time</label>
                            <input type="time" id="start_time" name="start_time" value="<?php echo e($store['start_time']); ?>" class="<?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="start_time" aria-describedby="start_time">
                            <?php $__errorArgs = ['color_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-right: 0;">
                            <label for="color_2">End Time</label>
                            <input type="time" id="end_time" name="end_time" value="<?php echo e($store['end_time']); ?>" class="<?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="end_time" aria-describedby="end_time">
                            <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <label for="currency">Currency</label>
                    <select id="currency" name="currency" class="form-select form-control" aria-label="Choose currency">
                        <option value="ج.م" <?php if ($store['currency'] == "ج.م") echo 'selected' ?>>ج.م</option>
                        <option value="$" <?php if ($store['currency'] == "$") echo 'selected' ?>>$</option>
                        <option value="€" <?php if ($store['currency'] == "€") echo 'selected' ?>>€</option>
                    </select>

                    <div class="d-flex flex-sm-row flex-column justify-content-between">
                        <div class="form-grou d-flex flex-column my-4 col-sm-6 input-x" style="padding-left: 0;">
                            <label for="whatsapp">Store Logo</label>
                            <input type="file" name="logo">
                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-right: 0;">
                            <?php if($store['logo']): ?>
                            <img style="max-height: 150px;" alt="logo" src="/images/<?php echo e($store['logo']); ?>" />
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="d-flex flex-column my-4">
                        <label>Delivery Options</label>
                        <div class="d-flex">
                            <div class="form-check mr-5">
                                <input class="form-check-input" type="checkbox" id="flexCheckChecked" name="dinIn" <?php if ($store['dinIn']) echo "checked" ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Din In
                                </label>
                            </div>

                            <div class="form-check mx-5">
                                <input class="form-check-input" type="checkbox" id="flexCheckChecked" name="pickUp" <?php if ($store['pickUp']) echo "checked" ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Pick up
                                </label>
                            </div>

                            <div class="form-check mx-5">
                                <input class="form-check-input" type="checkbox" id="flexCheckChecked" name="delivery" <?php if ($store['delivery']) echo "checked" ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Delivery
                                </label>
                            </div>
                        </div>
                    </div>


                    <label>Check this input if you want to display products as cards.</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="flexCheckChecked" name="displayCards" <?php if ($store['displayCards']) echo "checked" ?>>
                        <label class="form-check-label" for="flexCheckChecked">
                            Display cards
                        </label>
                    </div>
                    <button type="submit" class="btn my-btn my-5">Edit Store</button>

                </form>

                <?php if($store['delivery']): ?>
                <form method="POST" class="my-5" action="<?php echo e(route('adminAddPlace')); ?>">
                    <?php echo csrf_field(); ?>
                    <h6>Edit OR Add New Delivery Place</h6>
                    <div class="d-flex flex-sm-row flex-column justify-content-between">
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-left: 0;">
                            <label for="deliveryPlaceName">Name</label>
                            <input type="text" id="deliveryPlaceName" name="placeName" class="form-control">
                        </div>
                        <div class="form-group my-4 col-sm-6 input-x" style="padding-left: 0;">
                            <label for="deliveryPlacePrice">Price</label>
                            <input type="number" id="deliveryPlacePrice" name="placePrice" class="form-control">
                        </div>
                    </div>
                    <button class="btn btn-secondary">Enter</button>
                </form>
                <?php endif; ?>

                <?php if(count($places)): ?>
                <div class="d-flex table-responsive">
                    <table class="table table-bordered ">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Place Name</th>
                                <th scope="col">Price</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($place['name']); ?></td>
                                <td><?php echo e($place['price']); ?></td>
                                <td class="d-flex">
                                    <form method="POST" action="<?php echo e(route('adminDeletePlace', ['id' => $place['id']])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn delete-store-btn">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
    </div>

    <script src="<?php echo e(asset('assets/dashboard/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/main.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/js/bootstrap-colorpicker.min.js"></script>
    <script>
        $('.colorpicker').colorpicker();
    </script>

    <script>
        $(document).ready(function() {
            $("#url").change(function(e) {
                if (e.target.value == '<?php echo $store['url'] ?>') {
                    $('#url-message-success').text("This URL is available.").removeClass('d-none');
                    $('#url-message-danger').addClass('d-none');
                } else {
                    $.ajax(`/stores/checkURL/${e.target.value}`, {
                        success: function(data, status, xhr) {
                            if (data.result) {
                                $('#url-message-success').text("This URL is available.").removeClass('d-none');
                                $('#url-message-danger').addClass('d-none');
                            } else {
                                $('#url-message-danger').text("This URL is not available.").removeClass('d-none');
                                $('#url-message-success').addClass('d-none');
                            }
                        },
                    });
                }
            });
        })
    </script>
</body>

</html><?php /**PATH C:\Users\East-Sound\Desktop\last\whatsStore_laravel-main\resources\views/admin/editStore.blade.php ENDPATH**/ ?>