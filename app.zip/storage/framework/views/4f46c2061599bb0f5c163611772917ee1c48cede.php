<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>How To Install React in Laravel 9 with Vite</title>

    <?php echo e(vite_assets()); ?>

</head>
<body>
	<div id="root">Hello world</div>
</body>
</html><?php /**PATH C:\Users\East-Sound\Desktop\last\whatsStore_laravel-main\resources\views/welcome.blade.php ENDPATH**/ ?>