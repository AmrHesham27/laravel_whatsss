<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Talabat</title>
    
    <link href="<?php echo e(asset('assets/css/store.css')); ?>" rel="stylesheet" />

    <?php echo e(vite_assets()); ?>

</head>
<body>
    <div id="root" data='<?php echo e($store); ?>'></div>
    <script>
        let navItem = document.getElementById
    </script>
</body>
</html><?php /**PATH C:\Users\East-Sound\Desktop\last\whatsStore_laravel-main\resources\views/customer.blade.php ENDPATH**/ ?>