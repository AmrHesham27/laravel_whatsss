<!doctype html>
<html lang="en">

<head>
  <title>Sidebar 01</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/style.css')); ?>">

  <link rel="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" type="text/css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.2/Chart.min.js"></script>
  <script src="https://kit.fontawesome.com/6cc7b35ba8.js" crossorigin="anonymous"></script>

  <style>
    .container {
      max-width: 700px;
    }

    body {
      color: green;
    }

    h2 {
      text-align: center;
      font-family: "Verdana", sans-serif;
      font-size: 1rem;
    }
  </style>
</head>

<body>

  <div class="wrapper d-flex align-items-stretch">
  <?php if (isset($component)) { $__componentOriginald6cd77e68c51df0a0b330968aa346e50151105dc = $component; } ?>
<?php $component = App\View\Components\Dashboard\SuperAdminNavbar::resolve(['active' => 'Home'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.super-admin-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\SuperAdminNavbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald6cd77e68c51df0a0b330968aa346e50151105dc)): ?>
<?php $component = $__componentOriginald6cd77e68c51df0a0b330968aa346e50151105dc; ?>
<?php unset($__componentOriginald6cd77e68c51df0a0b330968aa346e50151105dc); ?>
<?php endif; ?>

    <!-- Page Content  -->
    <div id="content" class="p-4 p-md-5">

      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">

          <button type="button" id="sidebarCollapse" class="btn btn-primary">
            <i class="fa fa-bars"></i>
            <span class="sr-only">Toggle Menu</span>
          </button>
          <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ml-auto">
              <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <a class="nav-link" href="route('logout')" onclick="event.preventDefault();
                                                this.closest('form').submit();">
                    <?php echo e(__('Log Out')); ?>

                  </a>
                </form>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                  <?php echo e(__('Profile')); ?>

                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- Content -->
      <div class="container">
        <h2>Views</h2>
        <div>
          <canvas id="myChart"></canvas>
        </div>
      </div>
    </div>
  </div>

  <script>
    var views = <?php echo $views[0] ?>;

    var ctx = document.getElementById("myChart").getContext("2d");
    var myChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: [
          new Date(Date.now() - (86400000 * 6)).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date(Date.now() - (86400000 * 5)).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date(Date.now() - (86400000 * 4)).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date(Date.now() - (86400000 * 3)).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date(Date.now() - (86400000 * 2)).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date(Date.now() - 86400000).toJSON().slice(5, 10).replace(/-/g, '/'),
          new Date().toJSON().slice(5, 10).replace(/-/g, '/'),
        ],
        datasets: [{
          label: "Total Views Count",
          data: [
            <?php echo $views[6] ?>,
            <?php echo $views[5] ?>,
            <?php echo $views[4] ?>,
            <?php echo $views[3] ?>,
            <?php echo $views[2] ?>,
            <?php echo $views[1] ?>,
            <?php echo $views[0] ?>
          ],
          backgroundColor: "#f8b739",
        }, ],
      },
    });
  </script>

  <script src="<?php echo e(asset('assets/dashboard/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/dashboard/js/popper.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/dashboard/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/dashboard/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\East-Sound\Desktop\last\whatsStore_laravel-main\resources\views/superAdmin/dashboard.blade.php ENDPATH**/ ?>