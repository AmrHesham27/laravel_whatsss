import './bootstrap';

import Alpine from 'alpinejs';

import './App.jsx'

window.Alpine = Alpine;

Alpine.start();
